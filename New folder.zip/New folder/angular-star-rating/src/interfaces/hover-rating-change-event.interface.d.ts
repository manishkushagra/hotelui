export interface HoverRatingChangeEvent {
    hoverRating: number;
}
