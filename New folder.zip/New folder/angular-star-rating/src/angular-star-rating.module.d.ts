import { ModuleWithProviders } from '@angular/core';
export declare class StarRatingModule {
    static forRoot(): ModuleWithProviders;
    static forChild(): ModuleWithProviders;
}
