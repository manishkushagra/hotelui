import { Component, OnInit } from '@angular/core';
import { ReviewService } from './review.service';
import { Review } from './review';
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

  review: Review;
  constructor(private service:ReviewService) { }

  getData(){
    this.service.getReview().subscribe(data=>this.review=data);
  }
  ngOnInit() {
    this.getData();
  }

}
