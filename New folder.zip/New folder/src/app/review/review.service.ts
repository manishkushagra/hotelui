
import { Injectable } from '@angular/core';
import{ HttpClient, HttpHeaders} from '@angular/common/http'
import { Observable,of } from 'rxjs';
import { Review } from './review';
import { catchError, tap } from 'rxjs/operators';
const httpOptions= {
  headers:new HttpHeaders({
    'Content-Type': 'application/json'
  })
}
@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  getReview(): Observable<Review>{
    console.log("in home service");
    return this.http.get<Review>('./assets/review.json').pipe(
      tap(data => console.log('Data fetched:'+JSON.stringify(data))));
  }
  constructor(private http:HttpClient) { }
  
}
