export class Review {
    constructor (
        public id:number,
        public name:string,
        public rating:number,
        public text: string,
        public title:string,
        public username:string
    ) 
    {}
}
 