import { BrowserModule } from 'node_modules/@angular/platform-browser';
import { NgModule } from 'node_modules/@angular/core';
import { StarRatingModule } from 'angular-star-rating';
import { HttpClientModule } from '@angular/common/http'; 
import { AppComponent } from './app.component';
import {HomeComponent} from './home/home.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HomeService } from './home/home.service';
import { ReviewService } from './review/review.service';
import { ReviewComponent } from './review/review.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ReviewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    HttpClientModule,
    
    StarRatingModule.forRoot()
  ],
  providers: [HomeService,ReviewService],
  bootstrap: [AppComponent]
})
export class AppModule { }
