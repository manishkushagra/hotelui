import { Injectable } from '@angular/core';
import{ HttpClient, HttpHeaders} from '@angular/common/http'
import { Observable,of } from 'rxjs';
import { Hotels } from './hotels';
import { catchError, tap } from 'rxjs/operators';
const httpOptions= {
  headers:new HttpHeaders({
    'Content-Type': 'application/json'
  })
}


@Injectable({
  providedIn: 'root'
})
export class HomeService {
  getDataHotels(): Observable<Hotels[]>{
    console.log("in home service");
    return this.http.get<Hotels[]>('./assets/hotels.json');
  }

  getCityNames(str: string): Observable<any>{
    console.log("in cityname func",str);
    return this.http.get<any>('https://localhost:8000/str').pipe(
      tap(data => console.log('Data fetched:'+JSON.stringify(data))));
  }

  constructor(private http:HttpClient) { }
}
