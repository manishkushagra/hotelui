export class Hotels {
    constructor (
        public id:number,
        public name:string,
        public rating:number,
        public address:string
    ) 
    {}
}
 