import { Component, OnInit } from '@angular/core';
import {Hotels} from './hotels';
import { HomeService } from './home.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 // city=['Patna','Kashi','Chutiya'];
  
  hotels:Hotels[];
  display=false;
  
  displayData(){
    console.log("hi");
    return this.display;
  }
  apple(data:any){
    console.log(data);
    
  }
  
  hlist:Hotels[];
  city:any;
  constructor(private service:HomeService) { }
  
  getData(){
    this.display=true;
    this.service.getDataHotels().subscribe(name=>this.hlist=name);
    console.log("print");
  }
  keyup(data: HTMLInputElement){
    console.log(data.value);
    this.service.getCityNames(data.value).subscribe(city=>this.city=city);
  }
  ngOnInit() {
    this.getData();
  }

}
