import { Component, OnInit } from '@angular/core';
import { ReviewService } from './review.service';
import { Review } from './review';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

  review: Review=new Review(0,"",0,"","","","");
  temp: Review=null;
  id: number;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service:ReviewService
    ){ }

  getData(id:number){
    this.service.getReview(id).subscribe(data=>{
      this.review=data;
    });
    
  }
  printDetail(){
    return this.review;
  }
  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        of(params.get('id'))
      )
    ).subscribe((d) => {
      this.id =+ d;
    });
    this.getData(this.id);
  }

}
