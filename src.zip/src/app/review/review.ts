export class Review {
    
    constructor (
        public id:number,
        public name:string,
        public reviews_rating:number,
        public reviews_text: string,
        public reviews_title:string,
        public reviews_username:string,
        public address: string
    ) 
    {}
}
 