import { Injectable } from '@angular/core';
import{ HttpClient, HttpHeaders,HttpParams} from '@angular/common/http'
import { Observable,of } from 'rxjs';
import { Hotels } from './hotels';
import { catchError, tap,map } from 'rxjs/operators';
const httpOptions= {
  headers:new HttpHeaders({
    'Content-Type': 'application/json'
  })
}


@Injectable({
  providedIn: 'root'
})
export class HomeService {
  list: string[];
  getDataHotels(value:string): Observable<Hotels[]>{
    return this.http.get<Hotels[]>('/api/city/'+value);
  }

  getCityNames(str: string): Observable<string[]>{
    return this.http.get<string[]>('/api/'+str);
  }
  constructor(private http:HttpClient) { }
}
