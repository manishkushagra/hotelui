import { Component, OnInit, HostListener } from '@angular/core';
import {Hotels} from './hotels';
import { HomeService } from './home.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  city=[];
  
  hotels:Hotels[];
 
  hotelList:Hotels[];

  constructor(private service:HomeService) { }
  
  getData(value: string){
    this.service.getDataHotels(value).subscribe(name=>this.hotelList=name);
  }
  keyup(data: HTMLInputElement){
    this.service.getCityNames(data.value).subscribe(city=>this.city=city);
  }
  ngOnInit() {
  }

}
