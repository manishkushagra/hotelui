export class Hotels {
    constructor (
        public id:number,
        public name:string,
        public reviews_rating:number,
        public address:string
    ) 
    {}
}
 