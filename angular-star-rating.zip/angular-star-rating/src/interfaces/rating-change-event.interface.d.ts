export interface RatingChangeEvent {
    rating: number;
}
