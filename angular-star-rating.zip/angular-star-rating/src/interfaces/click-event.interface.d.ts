export interface ClickEvent {
    rating: number;
}
